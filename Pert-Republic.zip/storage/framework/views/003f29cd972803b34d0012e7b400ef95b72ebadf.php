<!DOCTYPE html>
<html lang="en-US">
<head>
   <meta charset="UTF-8" />
   <meta name="description" content=""/>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">

   <title> Pert Republic </title>

   <!-- STYLES -->
   <link rel="stylesheet" type="text/css" href="/TEMPLATES/Luxury-master/css/style.css"/>
   <link rel="stylesheet" type="text/css" href="/TEMPLATES/Luxury-master/css/bootstrap.css"/>
   <link rel="stylesheet" type="text/css" href="/TEMPLATES/Luxury-master/css/bootstrap-social.css"/>

   <!-- OTHERS -->
   <link rel="stylesheet" type="text/css" href="/TEMPLATES/Luxury-master/css/picto-foundry-emotions.css" />
   <link rel="stylesheet" type="text/css" href="/TEMPLATES/Luxury-master/css/picto-foundry-household.css" />
   <link rel="stylesheet" type="text/css" href="/TEMPLATES/Luxury-master/css/picto-foundry-shopping-finance.css" />
   <link rel="stylesheet" type="text/css" href="/TEMPLATES/Luxury-master/css/picto-foundry-weather.css" />
   <link rel="stylesheet" type="text/css" href="/TEMPLATES/Luxury-master/css/picto-foundry-general.css" />

   <!-- FONTS -->
   <link rel="stylesheet" type="text/css" href="/TEMPLATES/Luxury-master/css/font-awesome.min.css"/>
</head>

<body>
   <div class="pushWrapper">
      <!-- Header (shown on mobile only) -->
      <header class="pageHeader">
         <!-- Menu Trigger -->
         <button class="menu-trigger">
            <span class="lines"></span>
         </button>
         <!-- Logo -->
         <a class="headerLogo smoothScroll" href="#">
            <i class=" step icon-lightning-2 size-26"></i>
            <span class="text" style="font-size: 20px"><b>Pert</b>Republic</span>
         </a>       
      </header>

      <!-- Sidebar -->
      <div class="sidebar">
         <nav class="mainMenu">
            <ul class="menu">
              <?php if(Route::has('login')): ?>
                  <?php if(Auth::check()): ?>
                     <li>
                        <a class="smoothScroll" title="Home">
                           <i class="step icon-home size-24"></i>
                           <span class="text">Home</span>
                        </a>
                     </li>
                  <?php else: ?>
                     <li>
                        <a class="smoothScroll" href="#signin-part" title="Sign In">
                           <i class="step icon-door-key size-24"></i>
                           <span class="text">Sign In</span>
                        </a>
                     </li>
                     <li>
                        <a href="<?php echo e(url('/register')); ?>" title="Sign Up">
                           <i class="icon-reciept-1 size-24"></i>
                           <span class="text">Sign Up</span>
                        </a>
                     </li>
                  <?php endif; ?>
               <?php endif; ?>
               <li style="border-top: 1px solid #2b3031; padding-top: 3em; margin-top: 4em;">
                   <a class="smoothScroll" href="#membership-part" title="About Us">
                     <i class="step icon-home-1 size-24"></i>
                     <span class="text">About Us</span>
                  </a>
               </li>
               <li>
                   <a class="smoothScroll" href="#membership-part" title="Partnerships">
                     <i class="step icon-group size-24"></i>
                     <span class="text">Partnerships</span>
                  </a>
               </li>
               <li>
                   <a class="smoothScroll" href="#membership-part" title="Parent Guides">
                     <i class="step icon-shield size-24"></i>
                     <span class="text">Parent Guides</span>
                  </a>
               </li>
               <li>
                   <a class="smoothScroll" href="#membership-part" title="Track my Orders">
                     <i class="step icon-location-pin size-24"></i>
                     <span class="text">Track my Orders</span>
                  </a>
               </li>
               <li>
                   <a class="smoothScroll" href="#membership-part" title="FAs">
                     <i class="step icon-question size-24"></i>
                     <span class="text">FAQs</span>
                  </a>
               </li>
            </ul>
         </nav>
         <nav class="backToTop">
            <ul class="backToTop-menu">
               <li>
                  <a class="smoothScroll" href="#section-intro" title="Back to Top">
                     <i class="fa fa-chevron-up"></i>
                     <span class="text">Back to top</span>
                  </a>
               </li>
            </ul>
         </nav>   
      </div>
   </div>

   <section class="section-intro" id="section-part" data-stellar-background-ratio="0.5" data-stellar-vertical-offset="0">
      <div class="content">
         <div class="container-template">
            <div class="container">
               <div class="row mb-small">
                  <div class="col-md-1"></div>
                  <div class="col-md-11 title-home">
                     <div class="headergroup-2">
                        <h1>Pert Republic</h1>
                        <h3 style="text-align: center;">
                           A playstore offering latest technologies and action-packed games just for you.
                        </h3>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-1"></div>
                     <div class="col-md-6 mb-small-img">
                        <img class="img-responsive" src="/TEMPLATES/Luxury-master/images/ADDED/template-mac.png" alt="">
                     </div>
                     <div class="col-md-5 mb-small-img" style="margin-top: -10px;"><br>
                        <div class="row">
                           <div class="col-md-10">
                              <h3 class="h3-style" style="text-align: center"> 
                                 Devices, Electronics,
                                 <br>Online & Offline Games.
                                 <br>We have covered everything.
                              </h3><br>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-md-10">
                              <h4 class="h3-style" style="text-align: justify; text-align-last: center;">
                                 Come on and join the whole community of gamers. Let's unite in one republic, only here in Pert Republic.
                              </h4>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-md-10">  
                              <a href="<?php echo e(url('/register')); ?>" class="btn btn-block btn-template-transparent-black" title="Sign Up For Free" style="margin-bottom: 30px;">
                                 Sign up for FREE
                              </a>
                              <a class="btn btn-block btn-social btn-facebook" href="/login/facebook" style="text-align: center">
                                 <span class="fa fa-facebook"></span>
                                 Sign up with Facebook
                              </a> 
                              <a class="btn btn-block btn-social btn-google" href="/login/google" style="text-align: center">
                                 <span class="fa fa-google"></span>
                                 Sign up with Google
                              </a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>

   <section class="timeline-part" id="signin-part">
      <div class="content">
         <div class="container-template">
            <div class="container">
               <div class="row">
                  <div class="col-md-1"></div>
                  <div class="col-md-11" style="margin-top: 10px;">
                     <div class="headergroup">
                        <h4>
                           Already have an account?
                        </h4>
                        <h2>
                           <span>Sign In Now</span>
                        </h2>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-1"></div>
                  <div class="intro content-template">
                     <div style="margin-top: -10px; text-align: justify; text-align-last: left;">
                        <p><strong>The leading provider and third-party supplier of latest technologies and PC games on the Philippines, today. </strong></p>
                        <p>Share your experiences to your friends with our best services. Make them know how you were served with the best quality products that we have. We, Pert Republic, will always be glad to serve all gamers around the Philippines.</p><br>
                        <p>Connect your different social media account to shout in the whole world that you are part of the Pert Republic.</p>
                     </div>
                     <div class="row">
                        <div class="col-md-6">
                           <a class="btn btn-block btn-social btn-facebook" href="/login/facebook">
                              <span class="fa fa-facebook"></span> Sign in with Facebook
                           </a>
                        </div>
                        <div class="col-md-6">
                           <a class="btn btn-block btn-social btn-google" href="/login/google">
                              <span class="fa fa-google"></span> Sign in with Google
                           </a>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-5">
                     <div class="form-box">
                        <div class="form-top">
                           <div class="form-top-left">
                              <h3>Pert Republic - Sign in</h3>
                              <p>Enter email and password to log in:</p>
                           </div>
                           <div class="form-top-right">
                              <i class="fa fa-lock"></i>
                           </div>
                        </div>
                        <div class="form-bottom">
                           <form action="<?php echo e(route('login')); ?>" method="POST" id="login-form">
                              <?php echo e(csrf_field()); ?>

                              <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                 <div class="input-group col-md-12">
                                    <span class="input-group-addon" for="form-username"> EMAIL ADD.</span>
                                    <input type="email" class="form-username form-control" name="email" id="email" value="<?php echo e(old('email')); ?>" required>
                                 </div>
                                 <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                 <?php endif; ?>
                              </div>
                              <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                 <div class="input-group col-md-12">
                                    <span class="input-group-addon" for="form-password"> PASSWORD </span>
                                    <input type="password" class="form-password form-control" name="password" id="password" required>
                                 </div>
                                 <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                 <?php endif; ?>
                              </div>
                              <div class="row" style="text-align: center;">
                                 <div class="col-md-12">
                                    <label>
                                        <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                    </label>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6"></div>
                                 <div class="col-md-6">
                                    <a href="<?php echo e(route('login')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('login-form').submit();" class="btn btn-block btn-template-transparent-black"> Sign in Now </a>
                                    <a class="btn btn-link" style="text-decoration: none; margin-top: 5px;" href="<?php echo e(route('password.request')); ?>">
                                       Forgot Your Password?
                                    </a>
                                 </div>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>

   <!-- SCRIPTS -->
   <script type='text/javascript' src='/TEMPLATES/Luxury-master/js/jquery.js'></script>
   <script type='text/javascript' src='/TEMPLATES/Luxury-master/js/jquery.mobile.custom.js'></script>
   <script type='text/javascript' src='/TEMPLATES/Luxury-master/js/response.js'></script>
   <script type='text/javascript' src='/TEMPLATES/Luxury-master/js/module.js'></script>
</body>  
</html>