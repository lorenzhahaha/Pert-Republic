<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap-4.0.0/dist/css/bootstrap.css')); ?>">
<style type="text/css">
    input[type=number]::-webkit-inner-spin-button {
        opacity: 1;
    }
    .container {
        margin: 100px 0px 100px 250px !important;
    }
</style>

<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"> CART ITEM 
                    <span class="badge badge-warning"> <?php echo e($cart_count); ?> </span>
                        <?php $total_amount = 0; ?>
                        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                $each_price = $cart -> product_price * $cart -> product_quantity;
                                $total_amount += $each_price;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge"> <?php echo e($total_amount); ?> </span>
                </div>

                <!-- PAYPAL PAYMENT -->
                <?php  $cart_products_number = 0; ?>
                <form>
                    <input type="hidden" name="cmd" value="_cart">
                    <input type="hidden" name="upload" value="1">
                    <!-- The value property holds the business email -->
                    <input type="hidden" name="business" value="lorenzflorentino18-seller@gmail.com">
                    
                    <!-- PRODUCT INFO -->
                    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $cart_products_number ++; ?>
                        <input type="hidden" name="item_name_<?php echo e($cart_products_number); ?>" value="<?php echo e($cart -> product_name); ?>">
                        <input type="hidden" name="item_number_<?php echo e($cart_products_number); ?>" value="<?php echo e($cart -> serial_code); ?>">
                        <input type="hidden" name="amount_<?php echo e($cart_products_number); ?>" value="<?php echo e($cart -> product_price); ?>">
                        <input type="hidden" name="quantity_<?php echo e($cart_products_number); ?>" value="<?php echo e($cart -> product_quantity); ?>">

                        <!-- SURCHARGES -->
                        <input type="hidden" name="shipping_<?php echo e($cart_products_number); ?>" value="1.75">
                        <input type="hidden" name="tax_<?php echo e($cart_products_number); ?>" value="0.12">

                        <input type="hidden" name="return" id="cancel_return" value="http://localhost:8000">
                        <input type="hidden" name="cancel_return" id="cancel_return" value="http://localhost:8000/show">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>

                    <!-- To implement in live, remove 'sandbox'. -->
                    <input name="submit" formaction="https://www.sandbox.paypal.com/cgi-bin/webscr" type="image" src="https://www.paypalobjects.com/webstatic/en_US/i/btn/png/gold-pill-paypalcheckout-34px.png">
                </form>

                <div class="panel-body">
                    <table class="table table-inverse table-bordered">
                        <thead>
                            <tr>
                                <th> Cart ID </th>
                                <th> Serial Code </th>
                                <th> Name </th>
                                <th> Price </th>
                                <th> Quantity </th>
                                <th> &nbsp; </th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $carts->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="color: #000;">
                                <td> <?php echo e($cart -> cart_id); ?> </td>
                                <td> <?php echo e($cart -> serial_code); ?> </td>
                                <td> <?php echo e($cart -> product_name); ?> </td>
                                <td> <?php echo e($cart -> product_price); ?> </td>
                                <td> 
                                    <form action="/update" method="POST" accept-charset="utf-8">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="input-group" style="z-index: 1 !important;">
                                        <input type="number" min="1" max="10" class="form-control" name="product_quantity" value="<?php echo e($cart -> product_quantity); ?>">
                                        <input type="hidden" name="customer_id" value="<?php echo e(Auth::user()->id); ?>">
                                        <input type="hidden" name="serial_code" value="<?php echo e($cart -> serial_code); ?>">
                                        
                                            <span class="input-group-btn">
                                                <button class="btn btn-warning" type="submit">
                                                    <i class="fa fa-refresh"></i>
                                                </button>
                                            </span>
                                        </div>
                                    </form>
                                </td>
                                <td>
                                    <form action="/remove" method="POST" accept-charset="utf-8">
                                    <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="customer_id" value="<?php echo e(Auth::user()->id); ?>">
                                        <input type="hidden" name="serial_code" value="<?php echo e($cart -> serial_code); ?>">
                                        <button class="btn btn-success" type="submit">
                                            <i class="fa fa-trash"></i>
                                        </button> 
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>